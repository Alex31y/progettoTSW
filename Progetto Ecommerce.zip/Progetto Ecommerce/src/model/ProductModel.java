package model;

import java.sql.SQLException;
import java.util.ArrayList;


public interface ProductModel {
	public void doSave(ArticoloBean product) throws SQLException;

	public boolean doDelete(int code) throws SQLException;

	public ArticoloBean doRetrieveByKey(int id) throws SQLException;
	
	public ArrayList<ArticoloBean> doRetrieveAll(String utente) throws SQLException;
}
