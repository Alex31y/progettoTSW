/**
 * documento associato a homepage.css
 */

$(document).ready(function() {
	$('#buttonCerca').click(function() {
		$.ajax({
			url : 'RicercaServlet',
			data : {
				richiesta : $('#bricerca').val()
			},
			success : function(responseText) {
				 alert(responseText);
			}
		});
	});
});

/*
function creaTable(responseText){
		  var table = document.getElementById("foundProducts");
		  var row = table.insertRow(0);
		  var cell1 = row.insertCell(0);
		  var cell2 = row.insertCell(1);
		  for(var i = 0; i < 3; i++){
			  cell1.innerHTML = responseText;
			  cell2.innerHTML = "NEW CELL2";
		  }
		
}
*/
/*
function creaTable(){
	
	var table = document.getElementById("foundProducts");
	var row = table.insertRow(0);
	var cell1 = row.insertCell(0);
	var cell2 = row.insertCell(1);
	
	var f = document.createElement("form");
	f.setAttribute('method',"get");
	f.setAttribute('action',"Servlet");
	
	var s = document.createElement("input"); //input element, Submit button
	s.setAttribute('type',"submit");
	s.setAttribute('value',"dettagli");

	if(session.getAttribute("trovati") != null){
		var trovati = session.getAttribute("trovati");
		var it = trovati.iterator();
			var el;
			while (it.hasNext()) {
				el = it.next();
				cell1.innerHTML = el.getNome();
				s.setAttribute('name',"dettagli" + el.getId());
				f.appendChild(s);
				cell2.appendChild(f);
			}
	}
}
*/
