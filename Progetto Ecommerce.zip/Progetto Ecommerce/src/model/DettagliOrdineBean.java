package model;

public class DettagliOrdineBean {


	public String getUtente() {
		return utente;
	}
	public void setUtente(String utente) {
		this.utente = utente;
	}
	public int getIdarticolo() {
		return idarticolo;
	}
	public void setIdarticolo(int idarticolo) {
		this.idarticolo = idarticolo;
	}
	public int getQuantita() {
		return quantita;
	}
	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}
	public int getNumeroOrdine() {
		return numeroOrdine;
	}
	public void setNumeroOrdine(int numeroOrdine) {
		this.numeroOrdine = numeroOrdine;
	}
	
	
	String utente;
	int idarticolo, quantita, numeroOrdine;
}
