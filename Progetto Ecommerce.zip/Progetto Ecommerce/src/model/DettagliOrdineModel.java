package model;

import java.sql.SQLException;
import java.util.ArrayList;

public interface DettagliOrdineModel {
	
	public ArrayList<DettagliOrdineBean>  doRetrieveByKey(int numeroOrdine) throws SQLException;

}
