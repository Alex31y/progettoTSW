package model;

import java.util.Calendar;




public class OrdineBean {
	public OrdineBean()
	{
		importo = 0;
	}


	public String getutente() {
		return utente;
	}
	public void setutente(String id) {
		this.utente = id;
	}
	public double getImporto() {
		return importo;
	}
	public void setImporto(double importo) {
		this.importo = importo;
	}
	public String getData() {
		return data;
	}
	
	public void setData(String data) {
		this.data = data; 
        
	}
	
	public void setDataAttuale(){
		
		 Calendar calendar = Calendar.getInstance();
	        java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());
	        data = startDate.toString();
	}
	public int getidOrdine() {
		return idOrdine;
	}


	public void setidOrdine(int numero_ordine) {
		this.idOrdine = numero_ordine;
	}

	int idOrdine;
	String utente;
	double importo;
	String data;
}
