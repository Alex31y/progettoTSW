package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.*;

@WebServlet("/ServletAdmin")
public class ServletAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ServletAdmin() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Enumeration<String> paramNames = request.getParameterNames();
		while(paramNames.hasMoreElements()) {
			String paramName = paramNames.nextElement();
			ProductModelDAO ds = new ProductModelDAO();
			//
			
			if(paramName.contains("change")) {
				ArticoloBean articolo = new ArticoloBean();
				articolo.setId(Integer.parseInt(paramName.substring(6)));
				articolo.setNome(request.getParameter("nome"));
				articolo.setDescrizione(request.getParameter("descrizione"));
				articolo.setPrezzo(Float.parseFloat(request.getParameter("prezzo")));
				
				try {
					ds.doModify(articolo);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
				response.sendRedirect("ADMIN/adminCatalogo.jsp");
			}
			else{
				
				switch(paramName) {
				case "add":
					ArticoloBean articolo = new ArticoloBean();
					articolo.setNome(request.getParameter("nome"));
					articolo.setDescrizione(request.getParameter("descrizione"));
					articolo.setPrezzo(Float.parseFloat(request.getParameter("prezzo")));
					
					try {
						ds.doSave(articolo);
					} catch (SQLException e) {
						e.printStackTrace();
					}
					
					response.sendRedirect("ADMIN/adminCatalogo.jsp");
				break;
				
				case "remove":
					try {
						ds.doDelete(Integer.parseInt(request.getParameter("id")));
					} catch (SQLException e) {
						e.printStackTrace();
					}
					
					System.out.println(request.getParameter("id"));
					response.sendRedirect("ADMIN/adminCatalogo.jsp");
				break;
				}
		}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
