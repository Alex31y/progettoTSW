package model;

import java.sql.SQLException;
import java.util.ArrayList;

public interface OrdineModel {

	public void doSave(String nick, Carrello carrello) throws SQLException ;

	public OrdineBean doRetrieveByKey(int numeroOrdine) throws SQLException;

    public ArrayList<OrdineBean> doRetrieveByDateAndName(String name, String date) throws SQLException;

    ArrayList<OrdineBean> doRetrieveAll() throws SQLException;
    
	public ArrayList<OrdineBean> doRetrieveAll(String order) throws SQLException;

	ArrayList<OrdineBean> doRetrieveByDate(String date) throws SQLException;

	ArrayList<OrdineBean> doRetrieveByName(String name) throws SQLException;
}
