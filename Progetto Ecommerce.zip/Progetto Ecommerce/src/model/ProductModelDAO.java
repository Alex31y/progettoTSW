package model;

import java.sql.*;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



public class ProductModelDAO implements ProductModel{

	private static DataSource ds;
	
	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}

	public void doSave(ArticoloBean product) throws SQLException {
		
	}
	
	public ArrayList<ArticoloBean> doRetrieveAll(String order) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ArrayList<ArticoloBean> articoli = new ArrayList<ArticoloBean>();
		
		String selectSQL = "SELECT * FROM " + ProductModelDAO.TABLE_NAME;
		if (order != null && !order.equals("")) {
			selectSQL += " ORDER BY " + order;
		}
		
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				ArticoloBean bean = new ArticoloBean();

				bean.setId(rs.getInt("idarticoli"));
				bean.setNome(rs.getString("nome"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setPrezzo(rs.getInt("prezzo"));
				bean.setImg(rs.getString("immagine"));
				articoli.add(bean);
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return articoli;
	}

	public ArticoloBean doRetrieveByKey(int id) throws SQLException{
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		ArticoloBean bean = new ArticoloBean();

		String selectSQL = "SELECT * FROM " + ProductModelDAO.TABLE_NAME + " WHERE idarticoli = ?";
		
		try {
			connection = ds.getConnection();
			preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id);

			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				bean.setId(rs.getInt("idarticoli"));
				bean.setNome(rs.getString("nome"));
				bean.setDescrizione(rs.getString("descrizione"));
				bean.setPrezzo(rs.getInt("prezzo"));
				bean.setImg(rs.getString("immagine"));
			}

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		return bean;
	}

	public boolean doDelete(int code) throws SQLException {
		return false;
	}
	
	private static final String TABLE_NAME = "articoli";
	}


