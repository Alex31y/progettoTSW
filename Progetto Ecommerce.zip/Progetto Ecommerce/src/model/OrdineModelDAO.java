package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class OrdineModelDAO implements OrdineModel {

	private static DataSource ds;

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	
	@Override
	public ArrayList<OrdineBean> doRetrieveByDate(String date) throws SQLException {
		Connection connection = null;
		ArrayList<OrdineBean> ordini = new ArrayList<OrdineBean>();
		
		connection = ds.getConnection();
		System.out.println("223 " + date);

		PreparedStatement stmt = connection.prepareStatement("SELECT * FROM " + OrdineModelDAO.TABLE_NAME + " WHERE DATA = ?");
		stmt.setString(1, date);
		ResultSet rs = stmt.executeQuery();
		while(rs.next())
		{
			OrdineBean ordine = new OrdineBean();
			ordine.setidOrdine(rs.getInt("idordine"));
			ordine.setData(rs.getString("DATA"));
			ordine.setImporto(rs.getFloat("importo"));
			ordine.setutente(rs.getString("utente"));
			ordini.add(ordine);
		}
		return ordini;
	}


	@Override
	public ArrayList<OrdineBean> doRetrieveByName(String name) throws SQLException {
		Connection connection = null;
		ArrayList<OrdineBean> ordini = new ArrayList<OrdineBean>();

		connection = ds.getConnection();

		PreparedStatement stmt = connection.prepareStatement("SELECT * FROM " + OrdineModelDAO.TABLE_NAME + " WHERE utente = ?");
		stmt.setString(1, name);
		ResultSet rs = stmt.executeQuery();
		while(rs.next())
		{
			OrdineBean ordine = new OrdineBean();
			ordine.setidOrdine(rs.getInt("idordine"));
			ordine.setData(rs.getString("DATA"));
			ordine.setImporto(rs.getFloat("importo"));
			ordine.setutente(rs.getString("utente"));
			ordini.add(ordine);
		}



		return ordini;
	}
	
	
	public ArrayList<OrdineBean> doRetrieveByDateAndName(String name, String date) throws SQLException {
		Connection connection = null;
		ArrayList<OrdineBean> ordini = new ArrayList<OrdineBean>();

		connection = ds.getConnection();


		PreparedStatement stmt = connection.prepareStatement("SELECT * FROM " + OrdineModelDAO.TABLE_NAME + " WHERE utente = ? AND DATA = ?");
		stmt.setString(1, name);
		stmt.setString(2, date);
		ResultSet rs = stmt.executeQuery();
		while(rs.next())
		{
			OrdineBean ordine = new OrdineBean();
			ordine.setidOrdine(rs.getInt("idordine"));
			ordine.setData(rs.getString("DATA"));
			ordine.setImporto(rs.getFloat("importo"));
			ordine.setutente(rs.getString("utente"));
			ordini.add(ordine);
		}

		return ordini;
	}

	public void doSave(String nick, Carrello carrello) throws SQLException {

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		OrdineBean ordine = new OrdineBean();
		int numero_ordine = 0;

		connection = ds.getConnection();


		String insertSQL = "INSERT INTO " + OrdineModelDAO.TABLE_NAME + "(importo, DATA, utente)  VALUES(?,?,?)" ;
		ordine.setImporto(carrello.getAmount());
		ordine.setDataAttuale();
		ordine.setutente(nick);

		System.out.println(ordine.utente + ordine.data + ordine.importo);


		try {
			
			preparedStatement = connection.prepareStatement(insertSQL);
			preparedStatement.setDouble(1, ordine.getImporto());
			preparedStatement.setString(2, ordine.getData());
			preparedStatement.setString(3, ordine.getutente());


			preparedStatement.executeUpdate();

		} finally {
			try {
				if (preparedStatement != null)
					preparedStatement.close();
			} finally {
				if (connection != null)
					connection.close();
			}
		}
		System.out.println("73");	
		connection = ds.getConnection();
		preparedStatement = connection.prepareStatement("SELECT MAX(idordine) FROM " + OrdineModelDAO.TABLE_NAME  + " WHERE utente = ?");
		preparedStatement.setString(1, nick);
		ResultSet rs = preparedStatement.executeQuery();
		System.out.println("78");
		if(rs.next())
		{
			numero_ordine = rs.getInt("MAX(idordine)");
		
		}
		
		
		
		System.out.println("86");
		List<ArticoloBean> elem = carrello.getArticoli();

		for( ArticoloBean art : elem)
		{
			insertSQL = "INSERT INTO " + OrdineModelDAO.TABLE_NAME2 + "(utente, idarticolo, quantita, numero_ordine)  VALUES(?,?,?,?)" ;
				

			try {
				connection = ds.getConnection();
				preparedStatement = connection.prepareStatement(insertSQL);
				preparedStatement.setString(1, ordine.getutente());
				preparedStatement.setInt(2, art.getId());
				preparedStatement.setInt(3, art.getPezzi());
				preparedStatement.setInt(4, numero_ordine);

				preparedStatement.executeUpdate();
				
				
				preparedStatement = connection.prepareStatement("UPDATE database.utente SET numero_ordini = numero_ordini+1  WHERE nickname = ?");
				preparedStatement.setString(1, nick);
				
				preparedStatement.executeUpdate();

			} finally {
				try {
					if (preparedStatement != null)
						preparedStatement.close();
				} finally {
					if (connection != null)
						connection.close();
				}
			}
		}
		
		preparedStatement.close();
	}
	
	public ArrayList<OrdineBean> doRetrieveAll() throws SQLException {

        Connection connection = null;
        ArrayList<OrdineBean> ordini = new ArrayList<OrdineBean>();

        System.out.println("prova 1");

        connection = ds.getConnection();


        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM " + OrdineModelDAO.TABLE_NAME );
        ResultSet rs = stmt.executeQuery();
        while(rs.next())
        {
            OrdineBean ordine = new OrdineBean();
            ordine.setidOrdine(rs.getInt("idordine"));
            ordine.setData(rs.getString("DATA"));
            ordine.setImporto(rs.getFloat("importo"));
            ordine.setutente(rs.getString("utente"));
            ordini.add(ordine);
        }



        return ordini;
    }


	@Override
	public ArrayList<OrdineBean> doRetrieveAll(String utente) throws SQLException {
		
		Connection connection = null;
		ArrayList<OrdineBean> ordini = new ArrayList<OrdineBean>();
		
		System.out.println("prova 1");

		connection = ds.getConnection();


		PreparedStatement stmt = connection.prepareStatement("SELECT * FROM " + OrdineModelDAO.TABLE_NAME + " WHERE utente = ?");
		stmt.setString(1, utente);
		ResultSet rs = stmt.executeQuery();
		while(rs.next())
		{
			OrdineBean ordine = new OrdineBean();
			ordine.setData(rs.getString("DATA"));
			ordine.setImporto(rs.getFloat("importo"));
			ordine.setidOrdine(rs.getInt("idordine"));
			ordini.add(ordine);
		}



		return ordini;
	}
	
	public OrdineBean doRetrieveByKey(int numeroOrdine) throws SQLException {
		
		Connection connection = null;
		OrdineBean ordine = new OrdineBean();
		
		connection = ds.getConnection();
		PreparedStatement stmt = connection.prepareStatement("SELECT * FROM " + OrdineModelDAO.TABLE_NAME + " WHERE idordine = ?");
		stmt.setInt(1, numeroOrdine);
		ResultSet rs = stmt.executeQuery();
		if(rs.next())
		{
			
			ordine.setData(rs.getString("DATA"));
			ordine.setImporto(rs.getFloat("importo"));
			ordine.setidOrdine(rs.getInt("idordine"));
			ordine.setutente(rs.getString("utente"));
		}

		return ordine;
		
	} 
		

	private static final String TABLE_NAME = "odrine";
	private static final String TABLE_NAME2 = "dettagli_ordine";




}
