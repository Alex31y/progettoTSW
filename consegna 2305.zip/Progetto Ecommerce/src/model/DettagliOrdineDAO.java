package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DettagliOrdineDAO implements DettagliOrdineModel {

	private static DataSource ds;

	static {
		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/storage");

		} catch (NamingException e) {
			System.out.println("Error:" + e.getMessage());
		}
	}
	
	

	
	public ArrayList<DettagliOrdineBean>  doRetrieveByKey(int numeroOrdine) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ArrayList<DettagliOrdineBean> ordini = new ArrayList<DettagliOrdineBean>();
		
		int numero_ordine = 0;
		
		System.out.println("prova 1");
		connection = ds.getConnection();

		PreparedStatement stmt = connection.prepareStatement("SELECT * FROM " + DettagliOrdineDAO.TABLE_NAME + " WHERE numero_ordine = ?");
		stmt.setInt(1, numeroOrdine);
		ResultSet rs = stmt.executeQuery();
		System.out.println("47");
		while(rs.next())
		{
			System.out.println("while");
			DettagliOrdineBean ordine = new DettagliOrdineBean();
			ordine.setUtente(rs.getString("utente"));
			ordine.setIdarticolo(rs.getInt("idarticolo"));
			ordine.setQuantita(rs.getInt("quantita"));
			ordine.setNumeroOrdine(rs.getInt("numero_ordine"));
			
			ordini.add(ordine);
		}

		System.out.println("59");
		System.out.println(ordini.toString());
		return ordini;
		
		
	}

	private static final String TABLE_NAME = "dettagli_ordine";
}
