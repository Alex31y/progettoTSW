package model;

import java.sql.SQLException;
import java.util.ArrayList;


public interface UtenteModel {
	public void doSave(UtenteBean product) throws SQLException;

	public boolean doDelete(int code) throws SQLException;

	public UtenteBean doRetrieveByKey(String id) throws SQLException;
	
	public ArrayList<UtenteBean> doRetrieveAll(String order) throws SQLException;
}
