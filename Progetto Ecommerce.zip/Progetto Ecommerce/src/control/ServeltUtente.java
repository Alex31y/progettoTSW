package control;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.*;


@WebServlet("/ServeltUtente")
public class ServeltUtente extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public ServeltUtente() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String userName = request.getParameter("userName").trim();
		String output = "nome utente gi� presente nel db";
		UtenteModel db = new UtenteModelDAO();
		
		if(userName == null || "".equals(userName)){
			output = "input non valido";
		} else
			try {
				if(db.doRetrieveByKey(userName).getNickname() == null) {
					output = "nome disponibile";
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
		
		response.setContentType("text/plain");
		response.getWriter().write(output);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
