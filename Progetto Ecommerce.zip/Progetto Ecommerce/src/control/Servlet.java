package control;
import model.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Servlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		RequestDispatcher view;
		Carrello cart = (Carrello) session.getAttribute("carrello");
		if(cart == null)
			cart = new Carrello();
		
		Enumeration<String> paramNames = request.getParameterNames();
		while(paramNames.hasMoreElements()) {
			String paramName = paramNames.nextElement();
			if(paramName.contains(".x")) {
				paramName =paramName.replace(".x", "");
			}
			
			if(paramName.contains("login")) {
				boolean trovato = false;
				try {
					UtenteModel dbUtente = new UtenteModelDAO();
					ArrayList<UtenteBean> utenti = dbUtente.doRetrieveAll("tipo");
					Iterator<UtenteBean> it = utenti.iterator();
					while(it.hasNext()) {
						UtenteBean user = it.next();
						if(user.getNickname().equals(request.getParameter("nickname"))) {
							if(user.getPassword().equals(request.getParameter("passw"))) {
								trovato = true;
							}
						}
					}
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
				if(trovato) {
					session.setAttribute("loggato", "true");
					session.setAttribute("nickname", request.getParameter("nickname"));
					response.sendRedirect("articoli.jsp");
				}
				else
					response.sendRedirect("login.jsp");
			}
			
			else if(paramName.contains("aquista")) {
				ProductModelDAO db = new ProductModelDAO();
				ArticoloBean elemento = null;
				try {
					elemento = db.doRetrieveByKey(Integer.parseInt(paramName.substring(7)));
				
				cart.addArticolo(elemento);
				session.setAttribute("carrello", cart);
				
				view = request.getRequestDispatcher("carrello.jsp");
				view.forward(request, response);
				
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			else if(paramName.contains("rimuovi")){
				ProductModelDAO db = new ProductModelDAO();
				ArticoloBean elemento = null;
				try {
					elemento = db.doRetrieveByKey(Integer.parseInt(paramName.substring(7)));
				
				cart.removeArticolo(elemento);
				session.setAttribute("carrello", cart);
				
				view = request.getRequestDispatcher("carrello.jsp");
				view.forward(request, response);
				
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			else if(paramName.contains("dettagli")) {
				session.setAttribute("idElem", Integer.parseInt(paramName.substring(8)));
				view = request.getRequestDispatcher("dettagli.jsp");
				view.forward(request, response);
			}
			else if(paramName.contains("change")) {
				cart.setPezziArticolo(Integer.parseInt(paramName.substring(6)), Integer.parseInt(request.getParameter("val" + paramName.substring(6))));
				
				view = request.getRequestDispatcher("carrello.jsp");
				view.forward(request, response);
			}
			else {
				switch(paramName) {
				case "paga":
					session.removeAttribute("carrello");
					response.sendRedirect("articoli.jsp");
					break;
				case "logout":
					session.setAttribute("loggato", "false");
					response.sendRedirect("articoli.jsp");
					break;
				case "signup":
					response.sendRedirect("registrazione.jsp");
					break;
				case "registrami":
					UtenteBean bean = new UtenteBean();
					bean.setNickname(request.getParameter("nickname"));
					bean.setPassword(request.getParameter("passw"));
					bean.setEmail(request.getParameter("email"));
					
					UtenteModel utenteDB = new UtenteModelDAO();
					try {
						utenteDB.doSave(bean);
					} catch (SQLException e) {
						e.printStackTrace();
					}
					response.sendRedirect("articoli.jsp");
					break;
				default:
					System.out.println("default " + paramName);
					break;
				}
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
