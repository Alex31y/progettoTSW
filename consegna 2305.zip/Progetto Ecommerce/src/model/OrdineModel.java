package model;

import java.sql.SQLException;
import java.util.ArrayList;

public interface OrdineModel {

	public void doSave(String nick, Carrello carrello) throws SQLException ;

	
	public ArrayList<OrdineBean> doRetrieveAll(String order) throws SQLException;
	
	public OrdineBean doRetrieveByKey(int numeroOrdine) throws SQLException;
	
}
